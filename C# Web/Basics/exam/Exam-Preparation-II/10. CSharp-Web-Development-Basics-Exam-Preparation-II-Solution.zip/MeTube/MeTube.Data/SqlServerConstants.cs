﻿namespace MeTube.Data
{
    public static class SqlServerConstants
    {
        public const string ConnectionString = "Data Source=.;Database=MeTube_iordan_93;Integrated Security=True";
    }
}
