﻿namespace P02_KingsGambit.Contracts
{
    public interface IKing : IBoss, IAttackable, INameable
    {
    }
}
