﻿namespace P02_KingsGambit.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
