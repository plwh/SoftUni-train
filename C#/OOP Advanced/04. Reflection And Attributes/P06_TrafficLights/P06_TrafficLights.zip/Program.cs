﻿using System;

namespace P06_TrafficLights
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < input.Length; j++)
                {
                    switch (input[j])
                    {
                        case "Red":
                            input[j] = "Green";
                            break;
                        case "Green":
                            input[j] = "Yellow";
                            break;
                        case "Yellow":
                            input[j] = "Red";
                            break;
                    }
                }

                Console.WriteLine(string.Join(" ", input));
            }
        }
    }
}
