﻿public interface IExecutable
{
    void Execute();
}
