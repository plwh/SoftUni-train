﻿public interface IGemFactory
{
    IGem CreateGem(string calrity, string gemType);
}
