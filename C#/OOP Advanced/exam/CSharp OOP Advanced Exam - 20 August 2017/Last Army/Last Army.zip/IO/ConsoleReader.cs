﻿using System;

namespace Last_Army.IO
{
    static class ConsoleReader
    {
        public static string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}