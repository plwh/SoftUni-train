﻿using System;

namespace Last_Army.IO
{
    class ConsoleWriter
    {
        public static void WriteLine(string output)
        {
            Console.WriteLine(output);
        }
    }
}