﻿using System;

public class AmmunitionFactory
{
    public AmmunitionFactory()
    {
    }

    public static IAmmunition CreateAmmunition(string name)
    {
        IAmmunition result = null;

        switch (name)
        {
            case "Helmet":
                result = new Helmet(name);
                break;
            case "Knife":
                result = new Knife(name);
                break;
            case "NightVision":
                result = new NightVision(name);
                break;
            case "AutomaticMachine":
                result = new AutomaticMachine(name);
                break;
            case "Gun":
                result = new Gun(name);
                break;
            case "MachineGun":
                result = new MachineGun(name);
                break;
            case "RPG":
                result = new RPG(name);
                break;
        }

        return result;
    }

    public static Ammunition CreateAmmunitions(string name, int number)
    {
        throw new NotImplementedException();
    }

    internal static Ammunition AddAmmunitions(string name, int number)
    {
        throw new NotImplementedException();
    }
}
