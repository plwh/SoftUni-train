﻿using System;
using System.Collections.Generic;
using System.Linq;

public class SoldiersFactory
{
    public SoldiersFactory()
    {
    }

    public static Soldier GenerateRanker(string name, int age, int experience, double endurance)
    {
        return new Ranker(name, age, experience, endurance);
    }

    public static Soldier GenerateCorporal(string name, int age, int experience, double endurance)
    {
        return new Corporal(name, age, experience, endurance);
    }

    public static Soldier GenerateSpecialForce(string name, int age, int experience, double endurance)
    {
        return new SpecialForce(name, age, experience, endurance);
    }
}
