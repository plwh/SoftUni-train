﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class OutputMessages
{
    public static string SoldierToString => @"{0} - {1}";

    public static string MissionDeclined { get; internal set; }
    public static string MissionSuccessful { get; internal set; }
    public static string MissionOnHold { get; internal set; }
}
