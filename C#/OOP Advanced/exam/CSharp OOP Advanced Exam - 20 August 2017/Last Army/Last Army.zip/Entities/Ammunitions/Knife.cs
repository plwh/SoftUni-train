﻿public class Knife : Ammunition
{
    public Knife(string name)
        : base (name, 0.4d)
    {
    }
}
