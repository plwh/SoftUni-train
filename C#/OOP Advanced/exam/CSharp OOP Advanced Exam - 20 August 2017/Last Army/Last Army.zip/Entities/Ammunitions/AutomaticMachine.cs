﻿public class AutomaticMachine : Ammunition
{
    public AutomaticMachine(string name)
        : base(name, 6.3d)
    {
    }
}