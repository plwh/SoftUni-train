﻿public class MachineGun : Ammunition
{
    public MachineGun(string name)
        : base(name, 10.6d)
    {
    }
}
