﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class WareHouse : IWareHouse
{
    private readonly AmmunitionFactory ammunitionFactory;
    private Dictionary<string, int> ammunitionQuantities;

    public WareHouse()
    {
        this.ammunitionQuantities = new Dictionary<string, int>();
        this.ammunitionFactory = new AmmunitionFactory();
    }

    private void AddAmmunitions(string name, int quantity)
    {
        if (!this.ammunitionQuantities.ContainsKey(name))
        {
            this.ammunitionQuantities[name] = 0;
        }
        
        this.ammunitionQuantities[name] += quantity;
    }

    public void EquipArmy(IArmy army)
    {
        throw new NotImplementedException();
    }
}

