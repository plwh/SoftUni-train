﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Hard : Mission
{
    public Hard(string name, double enduranceRequired, double scoreToComplete) 
        : base(name, 80, scoreToComplete)
    {
    }
}
