﻿using System;
using System.Collections.Generic;
using System.Text;

abstract class Shape
{
    public abstract void Draw();
}
