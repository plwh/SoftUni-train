﻿using System;
using System.Collections.Generic;
using System.Text;

public class Mushrooms : Food
{
    public Mushrooms(int points) : base(points)
    { }
}
