﻿using System;
using System.Collections.Generic;
using System.Text;

public class Lembas : Food
{
    public Lembas(int points) : base(points)
    { }
}
