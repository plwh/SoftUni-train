﻿using System;
using System.Collections.Generic;
using System.Text;

public class Melon : Food
{
    public Melon(int points) : base(points)
    { }
}
