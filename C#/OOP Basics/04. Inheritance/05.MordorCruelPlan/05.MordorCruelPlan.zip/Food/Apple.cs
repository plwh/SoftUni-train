﻿using System;
using System.Collections.Generic;
using System.Text;

public class Apple : Food
{
    public Apple(int points) : base(points)
    { }
}
