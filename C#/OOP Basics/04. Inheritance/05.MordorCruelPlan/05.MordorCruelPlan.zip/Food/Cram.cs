﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cram : Food
{
    public Cram(int points) : base(points)
    { }
}
