﻿using System;
using System.Collections.Generic;
using System.Text;

public class Misc : Food
{
    public Misc(int points) : base(points)
    { }
}
