﻿using System;
using System.Collections.Generic;
using System.Text;

public class Solar : Provider
{
    public Solar(string id, double energyOutput) 
        : base(id, energyOutput)
    {
    }
}
