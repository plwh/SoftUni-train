﻿namespace DungeonsAndCodeWizards.Models
{
    public class Satchel : Bag
    {
        public Satchel() 
            : base(20)
        {
        }
    }
}
