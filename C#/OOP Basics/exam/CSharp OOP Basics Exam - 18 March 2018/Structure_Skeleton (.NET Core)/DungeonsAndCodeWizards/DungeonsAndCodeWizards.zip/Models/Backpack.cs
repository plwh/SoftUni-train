﻿namespace DungeonsAndCodeWizards.Models
{
    public class Backpack : Bag
    {
        public Backpack() 
            : base()
        {
        }
    }
}
