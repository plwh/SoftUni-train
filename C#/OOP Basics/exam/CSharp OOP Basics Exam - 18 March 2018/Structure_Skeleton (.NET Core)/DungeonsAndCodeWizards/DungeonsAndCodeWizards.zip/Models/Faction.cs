﻿namespace DungeonsAndCodeWizards.Models
{
    public enum Faction
    {
        CSharp, Java
    }
}