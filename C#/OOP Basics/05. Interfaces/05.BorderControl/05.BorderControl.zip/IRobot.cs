﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IRobot
{
    string Model { get; set; }
    string Id { get; set; }
}
