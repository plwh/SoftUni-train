﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ICallable
{
    void CallNumber(string number);
}
